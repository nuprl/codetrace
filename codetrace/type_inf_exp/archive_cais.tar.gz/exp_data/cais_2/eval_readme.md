## Steering Results
574 / 1504 = 0.3816489361702128
## Arguments
outdir : cais_2
dataset : franlucc/py_steering_v0
model : bigcode/starcoderbase-1b
prog_threshold : 10000000
type_threshold : 10000000
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'str': 497, 'int': 220, 'Any': 116, 'object': 99, 'float': 43, 'dict': 41, 'bool': 37, 'UserProfile': 35, 'bytes': 26, 'Path': 22, 'any': 14, 'type': 13, 'HttpRequest': 11, 'Mock': 11, 'Entity': 10, 'Callable': 9, 'T': 9, 'Decimal': 9, 'Request': 8, 'Mol': 8, 'datetime': 7, 'Dict': 7, 'Bot': 6, 'User': 6, 'Context': 6, 'Trace': 6, 'Logger': 5, 'Project': 5, 'Update': 5, 'None': 5, 'URL': 5, 'Iterable': 5, 'Sequence': 5, 'Replica': 5, 'Numeric': 5, 'Point': 5, 'Node': 4, 'list': 4, 'Element': 4, 'PID': 4, 'Exception': 4, 'Container': 4, 'tuple': 4, 'Response': 4, 'Token': 4, 'RequestId': 4, 'Props': 3, 'Realm': 3, 'List': 3, 'Component': 3, 'Mapping': 3, 'Language': 3, 'Database': 3, 'Population': 3, 'Piece': 3, 'JSON': 3, 'Frame': 3, 'Article': 3, 'timedelta': 2, 'date': 2, 'Type': 2, 'Message': 2, 'Person': 2, 'Digest': 2, 'Model': 2, 'Line': 2, 'A': 2, 'Board': 2, 'Branch': 2, 'Remote': 2, 'Field': 2, 'Document': 2, 'TestCase': 2, 'Session': 2, 'Money': 2, 'Formula': 2, 'Breadcrumb': 2, 'Letter': 2, 'Platform': 2, 'Cell': 2, 'Key': 2, 'Title': 1, 'Buckets': 1, 'ValueType': 1, 'DataFrame': 1, 'Circuit': 1, 'decimal': 1, 'Tracer': 1, 'Result': 1, 'Client': 1, 'Dot': 1, 'Base': 1, 'Account': 1, 'Bool': 1, 'Env': 1, 'Schema': 1, 'Instance': 1, 'set': 1, 'Text': 1, 'Cache': 1, 'Stage': 1, 'Scope': 1, 'L': 1, 'Word': 1, 'MP': 1, 'Reference': 1, 'Listener': 1, 'Column': 1, 'time': 1, 'Extension': 1, 'Section': 1, 'Table': 1, 'Mention': 1, 'Set': 1, 'FileManager': 1, 'Transformer': 1, 'Uploader': 1, 'Definitions': 1, 'ServiceName': 1, 'Credential': 1, 'Func': 1, 'Route': 1, 'Notification': 1, 'Metric': 1, 'Measurement': 1, 'Msg': 1, 'UserId': 1, 'LogEntry': 1, 'Storage': 1, 'Payment': 1, 'Options': 1, 'Api': 1, 'Config': 1, 'Caption': 1, 'Flask': 1, 'Authorization': 1, 'Grid': 1})