Given that typeinf steering (incorrect->correct) works using rename tensors, try the inverse:
does fixing renaming work with typeinf steering tensors?
steering tensor taken from cais_14