## Steering Results
30 / 184 = 0.16304347826086957
## Arguments
outdir : cais_1
dataset : franlucc/py_steering_v0
model : bigcode/starcoderbase-1b
prog_threshold : 1
type_threshold : 10
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>', '<fim_suffix>']
layers_to_patch : [15, 16, 17, 18]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'int': 10, 'object': 9, 'bool': 8, 'str': 8, 'bytes': 8, 'any': 8, 'datetime': 7, 'UserProfile': 7, 'HttpRequest': 7, 'float': 7, 'Logger': 7, 'User': 7, 'Update': 6, 'Any': 5, 'None': 5, 'PID': 5, 'Mol': 5, 'dict': 4, 'Bot': 4, 'Component': 4, 'Container': 4, 'Props': 3, 'Path': 3, 'Mock': 3, 'Dict': 3, 'Project': 3, 'Context': 3, 'Node': 2, 'list': 2, 'Element': 2, 'Realm': 2, 'Callable': 2, 'timedelta': 2, 'date': 2, 'Segment': 1, 'DataFrame': 1, 'Circuit': 1, 'decimal': 1, 'Exception': 1, 'Tracer': 1, 'Span': 1, 'Request': 1, 'Lookup': 1, 'List': 1, 'Host': 1, 'Book': 1, 'URL': 1, 'Iterable': 1, 'Result': 1, 'Type': 1, 'Expression': 1})