## Steering Results
89 / 177 = 0.5028248587570622
## Arguments
outdir : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_12
dataset : franlucc/stenotype-typeinf-1tok-completions
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100000
batch_size : 25
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : []
test_size : 0.1
fim_placeholder : True
multiplier : 1
custom_decoder : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/models/model_final.pt
steering_outfile : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_12/steered_predictions.json

Eval type distribution
Counter({'string': 38, 'number': 32, 'any': 19, 'T': 14, 'unknown': 8, 'boolean': 7, 'void': 5, 'Date': 4, 'State': 4, 'Color': 2, 'K': 2, 'object': 2, 'Vector': 2, 'Node': 2, 'Function': 2, 'Key': 2, 'Point': 2, 'never': 1, 'Error': 1, 'Row': 1, 'ValueType': 1, 'undefined': 1, 'JsonKey': 1, 'Options': 1, 'Argument': 1, 'Edge': 1, 'Constructor': 1, 'JsonValue': 1, 'Vertex': 1, 'Result': 1, 'Pitch': 1, 'TypeDef': 1, 'TValue': 1, 'Params': 1, 'Access': 1, 'Triangle': 1, 'bigint': 1, 'Action': 1, 'Input': 1, 'Source': 1, 'Args': 1, 'Board': 1, 'this': 1, 'digit': 1, 'B': 1, 'Position': 1, 'Segment': 1})