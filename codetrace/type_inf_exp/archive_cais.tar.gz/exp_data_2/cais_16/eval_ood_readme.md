## Steering Results
86 / 125 = 0.688
## Arguments
outdir : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_16
dataset : franlucc/stenotype-typeinf-1tok-completions
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 100000
type_threshold : 100000
batch_size : 25
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.1
fim_placeholder : True
multiplier : 1
custom_decoder : False
steering_outfile : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_16/ood_steered_predictions.json

Eval type distribution
Counter({'any': 227, 'string': 225, 'number': 220, 'T': 82, 'void': 57, 'boolean': 38, 'Date': 30, 'unknown': 16, 'Vector': 16, 'Matrix': 11, 'Error': 10, 'K': 9, 'Row': 9, 'ValueType': 9, 'Function': 7, 'never': 7, 'Color': 7, 'TKey': 6, 'object': 5, 'Constructor': 5, 'Key': 5, 'Board': 5, 'Options': 4, 'Node': 4, 'Argument': 4, 'Vertex': 4, 'Heap': 4, 'Answer': 4, 'Point': 4, 'Object': 4, 'Id': 4, 'undefined': 3, 'Hue': 3, 'Polygon': 3, 'bigint': 3, 'Source': 3, 'U': 3, '{}': 2, 'TypeDef': 2, 'State': 2, 'ArrayBuffer': 2, 'Position': 2, 'RegExp': 2, 'Command': 2, 'V': 2, 'Args': 2, 'Difficulty': 2, 'Index': 2, 'Column': 2, 'primitive': 2, 'A': 2, 'Range': 2, 'Group': 1, 'ElementType': 1, 'Edge': 1, 'G': 1, 'TValue': 1, 'HttpResponse': 1, 'Access': 1, 'Triangle': 1, 'Resolved': 1, 'Table': 1, 'Field': 1, 'C': 1, 'Err': 1, 'Primitive': 1, 'this': 1, 'Piece': 1, 'Graph': 1, 'Rgb': 1, 'XYZ': 1, 'Metadata': 1, 'ClassType': 1, 'Order': 1, 'TTT': 1, 'B': 1})