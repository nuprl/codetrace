## Steering Results
42 / 69 = 0.6086956521739131
## Arguments
outdir : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_20
dataset : franlucc/stenotype-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 100000
type_threshold : 100000
batch_size : 10
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.1
fim_placeholder : True
multiplier : 1
custom_decoder : False
steering_outfile : /home/franlucc/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_20/ood_steered_predictions.json

Eval type distribution
Counter({'number': 130, 'any': 94, 'string': 71, 'RegExp': 44, 'void': 43, 'boolean': 24, 'Cx': 19, 'unknown': 19, 'Vertex': 19, 'ArrayBuffer': 18, 'Color': 16, 'Group': 15, 'HttpResponse': 14, 'Order': 13, 'T': 11, 'Point': 10, 'SearchResult': 9, 'Workflow': 8, 'Position': 7, 'Id': 1, 'Command': 1})