The renamed steerign tensor works on vanilla typeinf, and the vanilla type inf tensor works (somewhat) on the renamed task.
What does this mean?
- there is a direction of "correct answer" that both these tensors point to
so, are these tensors cumulative?
Lets add them both and see if the result is better than the individual tensors.