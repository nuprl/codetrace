## Steering Results
25 / 69 = 0.36231884057971014
## Arguments
outdir : /data/francesca_lucchetti/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_6
dataset : franlucc/stenotype-typeinf-steering
model : bigcode/starcoderbase-1b
prog_threshold : 100000
type_threshold : 100000
batch_size : 10
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.1
fim_placeholder : True
steering_outfile : /data/francesca_lucchetti/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_6/ood_steered_predictions.json

Eval type distribution
Counter({'number': 130, 'any': 94, 'string': 71, 'RegExp': 44, 'void': 43, 'boolean': 24, 'Cx': 19, 'unknown': 19, 'Vertex': 19, 'ArrayBuffer': 18, 'Color': 16, 'Group': 15, 'HttpResponse': 14, 'Order': 13, 'T': 11, 'Point': 10, 'SearchResult': 9, 'Workflow': 8, 'Position': 7, 'Id': 1, 'Command': 1})