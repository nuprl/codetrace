## Steering Results
147 / 383 = 0.3838120104438642
## Arguments
outdir : /data/francesca_lucchetti/projects/codetrace/codetrace/type_inf_exp/exp_data/cais_2
dataset : franlucc/py_steering_v0
model : bigcode/starcoderbase-1b
prog_threshold : 10000000
type_threshold : 10000000
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'str': 513, 'int': 218, 'object': 114, 'Any': 78, 'float': 51, 'bool': 47, 'dict': 46, 'any': 23, 'Path': 20, 'type': 15, 'Request': 12, 'Decimal': 12, 'datetime': 11, 'Callable': 10, 'User': 10, 'T': 10, 'Entity': 10, 'bytes': 9, 'Mock': 9, 'Mol': 8, 'HttpRequest': 8, 'Context': 7, 'Trace': 7, 'Component': 6, 'Sequence': 6, 'Replica': 6, 'Numeric': 6, 'Point': 6, 'PID': 5, 'Exception': 5, 'list': 5, 'None': 5, 'URL': 5, 'Iterable': 5, 'Response': 5, 'Container': 4, 'Dict': 4, 'tuple': 4, 'Database': 4, 'Token': 4, 'Population': 4, 'JSON': 4, 'RequestId': 4, 'Props': 3, 'List': 3, 'Project': 3, 'Message': 3, 'Digest': 3, 'Mapping': 3, 'Language': 3, 'A': 3, 'Remote': 3, 'Branch': 3, 'Session': 3, 'Piece': 3, 'Flask': 3, 'Element': 3, 'Frame': 3, 'Formula': 3, 'Article': 3, 'Update': 2, 'Bot': 2, 'DataFrame': 2, 'timedelta': 2, 'date': 2, 'Type': 2, 'Node': 2, 'Person': 2, 'Model': 2, 'Line': 2, 'Listener': 2, 'Board': 2, 'Field': 2, 'Document': 2, 'Set': 2, 'TestCase': 2, 'Money': 2, 'Breadcrumb': 2, 'Letter': 2, 'Platform': 2, 'Authorization': 2, 'Cell': 2, 'Grid': 2, 'Key': 2, 'Circuit': 1, 'decimal': 1, 'Tracer': 1, 'Span': 1, 'Lookup': 1, 'Host': 1, 'Book': 1, 'Result': 1, 'Expression': 1, 'Client': 1, 'Dot': 1, 'Base': 1, 'Account': 1, 'Bool': 1, 'Env': 1, 'Schema': 1, 'Instance': 1, 'set': 1, 'Chapter': 1, 'Text': 1, 'Fragment': 1, 'Cache': 1, 'Stage': 1, 'Scope': 1, 'LineNumber': 1, 'Sign': 1, 'L': 1, 'Word': 1, 'MP': 1, 'Reference': 1, 'Column': 1, 'time': 1, 'Params': 1, 'Extension': 1, 'Figure': 1, 'Section': 1, 'Table': 1, 'Paragraph': 1, 'Mention': 1, 'Dependency': 1, 'FileManager': 1, 'Transformer': 1, 'Uploader': 1, 'Definitions': 1, 'ServiceName': 1, 'Credential': 1, 'Func': 1, 'Route': 1, 'Report': 1, 'Notification': 1, 'Metric': 1, 'Measurement': 1, 'Msg': 1, 'UserId': 1, 'LogEntry': 1, 'Storage': 1, 'Format': 1, 'Payment': 1, 'Options': 1, 'Api': 1, 'Config': 1, 'Site': 1, 'Caption': 1, 'Data': 1, 'Style': 1})