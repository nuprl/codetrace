## Steering Results
17 / 31 = 0.5483870967741935
## Arguments
outdir : 57
dataset : franlucc/py_steering_v0
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 25
type_threshold : 1
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'bool': 1, 'Node': 1, 'Any': 1, 'Props': 1, 'Title': 1, 'list': 1, 'datetime': 1, 'UserProfile': 1, 'Realm': 1, 'Element': 1, 'bytes': 1, 'HttpRequest': 1, 'Path': 1, 'dict': 1, 'None': 1, 'Mock': 1, 'object': 1, 'float': 1, 'Callable': 1, 'Dict': 1, 'Update': 1, 'Bot': 1, 'DataFrame': 1, 'Circuit': 1, 'PID': 1, 'any': 1, 'decimal': 1, 'timedelta': 1, 'Exception': 1, 'Tracer': 1, 'Span': 1, 'Lookup': 1, 'List': 1, 'Host': 1, 'User': 1, 'date': 1, 'Component': 1, 'Container': 1, 'Iterable': 1, 'Result': 1, 'Type': 1, 'Context': 1, 'Message': 1, 'Person': 1, 'Dot': 1, 'Digest': 1, 'Base': 1, 'Account': 1, 'T': 1, 'Bool': 1, 'Env': 1, 'set': 1, 'Mapping': 1, 'Text': 1, 'tuple': 1, 'Response': 1, 'Cache': 1, 'Scope': 1, 'LineNumber': 1, 'Database': 1, 'A': 1, 'Sign': 1, 'Sequence': 1, 'L': 1, 'Word': 1, 'Token': 1, 'MP': 1, 'Reference': 1, 'Listener': 1, 'Column': 1, 'Population': 1, 'Board': 1, 'Branch': 1, 'Session': 1, 'time': 1, 'Field': 1, 'type': 1, 'Flask': 1, 'Extension': 1, 'Figure': 1, 'Document': 1, 'Section': 1, 'Table': 1, 'Paragraph': 1, 'Mention': 1, 'Set': 1, 'Dependency': 1, 'FileManager': 1, 'Transformer': 1, 'Uploader': 1, 'Replica': 1, 'Definitions': 1, 'JSON': 1, 'ServiceName': 1, 'RequestId': 1, 'Credential': 1, 'Route': 1, 'Report': 1, 'Entity': 1, 'TestCase': 1, 'Notification': 1, 'Metric': 1, 'Measurement': 1, 'Msg': 1, 'UserId': 1, 'LogEntry': 1, 'Format': 1, 'Frame': 1, 'Numeric': 1, 'Payment': 1, 'Formula': 1, 'Trace': 1, 'Breadcrumb': 1, 'Options': 1, 'Article': 1, 'Config': 1, 'Site': 1, 'Letter': 1, 'Caption': 1, 'Data': 1, 'Style': 1, 'Platform': 1, 'Authorization': 1, 'Cell': 1, 'Grid': 1, 'Key': 1})