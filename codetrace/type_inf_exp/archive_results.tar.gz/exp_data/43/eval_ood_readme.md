## Steering Results
7 / 18 = 0.3888888888888889
## Arguments
outdir : 43
dataset : franlucc/ts-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 30
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 25, 'number': 16, 'boolean': 8, 'any': 6, 'Type': 2, 'unknown': 2, 'Date': 2, 'Options': 1, 'TResult': 1, 'Instruction': 1, 'ServiceProvider': 1, 'Rule': 1, 'void': 1, 'None': 1, 'Element': 1, 'Area': 1, 'Address': 1, 'T': 1, 'Bounds': 1})