## Steering Results
10 / 19 = 0.5263157894736842
## Arguments
outdir : 48
dataset : franlucc/stenotype-typeinf-1tok-completions
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 15, 'number': 13, 'unknown': 8, 'any': 7, 'void': 6, 'T': 6, 'boolean': 3, 'Function': 2, 'Date': 2, 'State': 2, 'A': 1, 'Group': 1, 'never': 1, 'ValueType': 1, 'object': 1, 'undefined': 1, 'symbol': 1, 'Vertex': 1, 'TypeDef': 1, 'Params': 1, 'Action': 1, 'Input': 1, 'C': 1})