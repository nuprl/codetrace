| Steering dataset                 | steering on fit      | steering on heldout set | dedup | prog/type dedup |
| -------------------------------- | -------------------- | ----------------------- | ----- | --------------- |
| pairs.jsonl v0                   | 574 / 1504 = 0.381   | 147 / 383 = 0.383       | false | N/A             |
| pairs.jsonl v0                   | 153 / 424 = 0.360    | 32 / 106 = 0.302        | true  | 25 / 10         |
| pairs.jsonl v1                   | waiting              | waiting                 | false | N/A             |
| stenotype-typeinf-steering       | 248 / 586 = 0.423    | 26 / 69 = 0.376         | false | N/A             |
| ts-typeinf-steering-p0           | 454 / 1134 = 0.400   | 664 / 1736 = 0.38       | false | N/A             |
