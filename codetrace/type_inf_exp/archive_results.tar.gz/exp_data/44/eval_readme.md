## Steering Results
16 / 29 = 0.5517241379310345
## Arguments
outdir : 44
dataset : franlucc/ts-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 10
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 9, 'number': 7, 'boolean': 3, 'any': 3, 'Options': 1, 'Type': 1, 'TResult': 1, 'Instruction': 1, 'Rule': 1, 'unknown': 1, 'void': 1})