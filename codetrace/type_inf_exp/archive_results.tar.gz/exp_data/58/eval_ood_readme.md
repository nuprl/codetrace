## Steering Results
32 / 106 = 0.3018867924528302
## Arguments
outdir : 58
dataset : franlucc/py_steering_v0
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 25
type_threshold : 10
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'int': 10, 'bytes': 10, 'User': 10, 'HttpRequest': 9, 'Mock': 9, 'Callable': 9, 'T': 9, 'datetime': 8, 'str': 8, 'UserProfile': 8, 'Path': 8, 'type': 8, 'Entity': 8, 'Any': 7, 'dict': 7, 'Logger': 7, 'any': 7, 'Request': 7, 'Mol': 7, 'Decimal': 7, 'bool': 6, 'Element': 6, 'None': 6, 'float': 6, 'Dict': 6, 'Component': 6, 'Context': 6, 'Trace': 6, 'object': 5, 'Project': 5, 'Bot': 5, 'Replica': 5, 'Numeric': 5, 'Node': 4, 'Props': 4, 'Update': 4, 'PID': 4, 'Exception': 4, 'URL': 4, 'Iterable': 4, 'Response': 4, 'Token': 4, 'JSON': 4, 'Point': 4, 'list': 3, 'List': 3, 'Container': 3, 'Message': 3, 'Digest': 3, 'tuple': 3, 'A': 3, 'Sequence': 3, 'Population': 3, 'Remote': 3, 'Branch': 3, 'Piece': 3, 'Frame': 3, 'Formula': 3, 'Realm': 2, 'DataFrame': 2, 'Model': 2, 'Line': 2, 'Language': 2, 'Database': 2, 'Listener': 2, 'Field': 2, 'Document': 2, 'Set': 2, 'Session': 2, 'Money': 2, 'Breadcrumb': 2, 'Article': 2, 'Flask': 2, 'Letter': 2, 'Platform': 2, 'Authorization': 2, 'Grid': 2, 'Title': 1, 'array': 1, 'Buckets': 1, 'ValueType': 1, 'Tracer': 1, 'Span': 1, 'Host': 1, 'date': 1, 'Result': 1, 'Client': 1, 'Person': 1, 'Dot': 1, 'Base': 1, 'Account': 1, 'Bool': 1, 'Env': 1, 'Schema': 1, 'Instance': 1, 'Chapter': 1, 'Mapping': 1, 'Text': 1, 'Fragment': 1, 'Cache': 1, 'LineNumber': 1, 'Sign': 1, 'Word': 1, 'MP': 1, 'Reference': 1, 'Board': 1, 'time': 1, 'Type': 1, 'Params': 1, 'Extension': 1, 'Figure': 1, 'Section': 1, 'Table': 1, 'Paragraph': 1, 'Mention': 1, 'Dependency': 1, 'FileManager': 1, 'Transformer': 1, 'Uploader': 1, 'Definitions': 1, 'ServiceName': 1, 'RequestId': 1, 'Credential': 1, 'Report': 1, 'TestCase': 1, 'Notification': 1, 'Measurement': 1, 'Msg': 1, 'UserId': 1, 'LogEntry': 1, 'Storage': 1, 'Format': 1, 'Payment': 1, 'Options': 1, 'Api': 1, 'Config': 1, 'Site': 1, 'Caption': 1, 'Data': 1, 'Style': 1, 'Cell': 1})