## Steering Results
1 / 4 = 0.25
## Arguments
outdir : 60
dataset : franlucc/py_steering_v0
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 1
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'bool': 1, 'Node': 1, 'Any': 1, 'Title': 1, 'array': 1, 'int': 1, 'datetime': 1, 'Realm': 1, 'str': 1, 'bytes': 1, 'HttpRequest': 1, 'Buckets': 1, 'Path': 1, 'ValueType': 1, 'dict': 1, 'None': 1})