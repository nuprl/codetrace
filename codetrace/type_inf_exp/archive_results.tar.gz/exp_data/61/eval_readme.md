## Steering Results
239 / 897 = 0.26644370122630995
## Arguments
outdir : 61
dataset : franlucc/py_steering_v0
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2
fim_placeholder : False

Eval type distribution
Counter({'Any': 79, 'str': 79, 'int': 77, 'object': 77, 'float': 48, 'dict': 39, 'bool': 37, 'UserProfile': 35, 'bytes': 27, 'Path': 23, 'any': 17, 'HttpRequest': 13, 'type': 13, 'Callable': 12, 'datetime': 11, 'Mock': 11, 'Request': 10, 'User': 9, 'T': 9, 'Decimal': 8, 'Entity': 8, 'Logger': 7, 'Trace': 7, 'list': 6, 'Update': 6, 'Numeric': 6, 'Point': 6, 'Element': 5, 'Dict': 5, 'Bot': 5, 'PID': 5, 'None': 5, 'Component': 5, 'URL': 5, 'Sequence': 5, 'Replica': 5, 'Node': 4, 'Props': 4, 'Project': 4, 'Exception': 4, 'Mol': 4, 'Container': 4, 'Context': 4, 'Response': 4, 'Database': 4, 'Token': 4, 'Realm': 3, 'List': 3, 'Iterable': 3, 'Mapping': 3, 'tuple': 3, 'Language': 3, 'JSON': 3, 'RequestId': 3, 'Formula': 3, 'timedelta': 2, 'date': 2, 'Message': 2, 'Digest': 2, 'Model': 2, 'Line': 2, 'Listener': 2, 'Population': 2, 'Board': 2, 'Branch': 2, 'Session': 2, 'Field': 2, 'Set': 2, 'Frame': 2, 'Flask': 2, 'Letter': 2, 'Platform': 2, 'Grid': 2, 'Key': 2, 'Title': 1, 'Buckets': 1, 'ValueType': 1, 'Segment': 1, 'DataFrame': 1, 'Circuit': 1, 'Tracer': 1, 'Span': 1, 'Host': 1, 'Book': 1, 'Client': 1, 'Dot': 1, 'Account': 1, 'Bool': 1, 'Env': 1, 'Schema': 1, 'Instance': 1, 'Chapter': 1, 'Text': 1, 'Fragment': 1, 'Scope': 1, 'LineNumber': 1, 'Sign': 1, 'L': 1, 'Word': 1, 'MP': 1, 'Reference': 1, 'Column': 1, 'time': 1, 'Remote': 1, 'Piece': 1, 'Params': 1, 'Extension': 1, 'Figure': 1, 'Table': 1, 'Mention': 1, 'Document': 1, 'Dependency': 1, 'FileManager': 1, 'Transformer': 1, 'Uploader': 1, 'Definitions': 1, 'ServiceName': 1, 'Credential': 1, 'Route': 1, 'Report': 1, 'TestCase': 1, 'Notification': 1, 'Metric': 1, 'Measurement': 1, 'Msg': 1, 'UserId': 1, 'LogEntry': 1, 'Format': 1, 'Money': 1, 'Payment': 1, 'Breadcrumb': 1, 'Options': 1, 'Article': 1, 'Api': 1, 'Config': 1, 'Site': 1, 'Caption': 1, 'Data': 1, 'Style': 1, 'Authorization': 1, 'Cell': 1})