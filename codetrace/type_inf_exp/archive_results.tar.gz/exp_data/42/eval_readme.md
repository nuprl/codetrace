## Steering Results
35 / 82 = 0.4268292682926829
## Arguments
outdir : 42
dataset : franlucc/ts-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 30
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_suffix>', '<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.1

Eval type distribution
Counter({'string': 26, 'number': 20, 'boolean': 8, 'any': 7, 'Type': 2, 'unknown': 2, 'void': 2, 'Date': 2, 'Options': 1, 'TResult': 1, 'Instruction': 1, 'ServiceProvider': 1, 'Rule': 1, 'None': 1, 'RegExp': 1, 'Element': 1, 'Area': 1, 'Error': 1, 'Address': 1, 'T': 1, 'Bounds': 1})