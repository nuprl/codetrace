## Steering Results
2 / 12 = 0.16666666666666666
## Arguments
outdir : 49
dataset : franlucc/stenotype-typeinf-1tok-completions
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'any': 4, 'unknown': 2, 'void': 1, 'A': 1, 'never': 1, 'Error': 1, 'undefined': 1, 'string': 1})