## Steering Results
6 / 26 = 0.23076923076923078
## Arguments
outdir : 40
dataset : franlucc/stenotype-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 3
type_threshold : 100
batch_size : 3
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14, 15, 16, 17, 18]
test_size : 0.1

Eval type distribution
Counter({'string': 7, 'number': 6, 'RegExp': 3, 'Point': 3, 'void': 3, 'T': 3, 'I': 1})