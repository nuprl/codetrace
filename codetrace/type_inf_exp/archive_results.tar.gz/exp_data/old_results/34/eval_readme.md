## Steering Results
7 / 15 = 0.4666666666666667
## Arguments
outdir : 34
dataset : franlucc/stenotype-eval-renamed-v5
model : /home/arjun/models/starcoderbase-1b
correct_prog_threshold : 1000
correct_type_threshold : 1000
incorrect_prog_threshold : 1000
incorrect_type_threshold : 1000
batch_size : 2
patch_mode : add
n_eval : 15
tokens_to_patch : ['<fim_suffix>', '<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 6, 'Color': 1, 'Section': 1, 'offsets': 1, 'Key': 1, 'Id': 1, 'SearchResult': 1, 'number': 1, 'Language': 1, 'any': 1})