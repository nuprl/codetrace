# Note

Maybe successful steered prompts (in green) can be differentiated because they are unique among a cluster of similars?