Correct
fim_type
any             7
number          5
string          3
boolean         2
Schema          1
Actions         1
Key             1
SearchResult    1
Container       1
RegExp          1
HttpResponse    1
Language        1
Section         1
Name: count, dtype: int64
hexsha
3f56768763456223c2ba0b091b90831e3aa1b8b3    2
9eb078d7d68852e0860617c539c62b7d3a9f0a9a    2
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    2
9232371dfa21a47ce397b18f5fd76f02d4b0d2b1    2
181ec44034d7ff44d9293788b657b1a2036d874b    1
d7288789b6e870c947d9b5d2c8fe51bb8de33ca3    1
4ab9eed9cbc53ed6e544dca10cf2f6417c2bdcd7    1
76a884ba965e8d7964d8852a0c0f228c1ae1d7ad    1
5bf8f0f2946da835300025c6804a609bef4277ab    1
97dca01248d8bc1f3e4e2fc93faa08dceabb61d6    1
1b0e94bf7d3c6477c0f89caf09f284b1c8441493    1
d7888589a5edea554ef38b5038cfe5db0eca64de    1
ac2f2620a73cd8792597b3c5d3baa98411d6543c    1
d7180447147db133f246707f18b8bdb014643e7a    1
ebfbabd6e86ee48c24c3828f4ee1b92f6ff39f68    1
53b6ef015e8c8793036ec97b599fa436cd131b3f    1
2f9ed4c5926a0fcede392151f980e017c0c93acb    1
361d89bb4743deb2ef0a6d1cd847cd5a2c9cb7db    1
23796ef71f89aeadfa7a847ca66d62e557cfdbbb    1
346ecbfdd79cec2fad1ef9b4f5ed650b93705bf7    1
9561f88ffc8f31e9c7d0151d058ab8d7dc194fb3    1
5516cd8e1144e5e75d37e49c3a7ed54395946de6    1
Name: count, dtype: int64
26

Incorrect
fim_type
any             7
number          5
string          3
boolean         2
Schema          1
Actions         1
Key             1
SearchResult    1
Container       1
RegExp          1
HttpResponse    1
Language        1
Section         1
Name: count, dtype: int64
hexsha
3f56768763456223c2ba0b091b90831e3aa1b8b3    2
9eb078d7d68852e0860617c539c62b7d3a9f0a9a    2
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    2
9232371dfa21a47ce397b18f5fd76f02d4b0d2b1    2
181ec44034d7ff44d9293788b657b1a2036d874b    1
d7288789b6e870c947d9b5d2c8fe51bb8de33ca3    1
4ab9eed9cbc53ed6e544dca10cf2f6417c2bdcd7    1
76a884ba965e8d7964d8852a0c0f228c1ae1d7ad    1
5bf8f0f2946da835300025c6804a609bef4277ab    1
97dca01248d8bc1f3e4e2fc93faa08dceabb61d6    1
1b0e94bf7d3c6477c0f89caf09f284b1c8441493    1
d7888589a5edea554ef38b5038cfe5db0eca64de    1
ac2f2620a73cd8792597b3c5d3baa98411d6543c    1
d7180447147db133f246707f18b8bdb014643e7a    1
ebfbabd6e86ee48c24c3828f4ee1b92f6ff39f68    1
53b6ef015e8c8793036ec97b599fa436cd131b3f    1
2f9ed4c5926a0fcede392151f980e017c0c93acb    1
361d89bb4743deb2ef0a6d1cd847cd5a2c9cb7db    1
23796ef71f89aeadfa7a847ca66d62e557cfdbbb    1
346ecbfdd79cec2fad1ef9b4f5ed650b93705bf7    1
9561f88ffc8f31e9c7d0151d058ab8d7dc194fb3    1
5516cd8e1144e5e75d37e49c3a7ed54395946de6    1
Name: count, dtype: int64
26

Incorrect Eval
fim_type
any             7
number          5
string          3
boolean         2
Schema          1
Actions         1
Key             1
SearchResult    1
Container       1
RegExp          1
HttpResponse    1
Language        1
Section         1
Name: count, dtype: int64
hexsha
3f56768763456223c2ba0b091b90831e3aa1b8b3    2
9eb078d7d68852e0860617c539c62b7d3a9f0a9a    2
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    2
9232371dfa21a47ce397b18f5fd76f02d4b0d2b1    2
181ec44034d7ff44d9293788b657b1a2036d874b    1
d7288789b6e870c947d9b5d2c8fe51bb8de33ca3    1
4ab9eed9cbc53ed6e544dca10cf2f6417c2bdcd7    1
76a884ba965e8d7964d8852a0c0f228c1ae1d7ad    1
5bf8f0f2946da835300025c6804a609bef4277ab    1
97dca01248d8bc1f3e4e2fc93faa08dceabb61d6    1
1b0e94bf7d3c6477c0f89caf09f284b1c8441493    1
d7888589a5edea554ef38b5038cfe5db0eca64de    1
ac2f2620a73cd8792597b3c5d3baa98411d6543c    1
d7180447147db133f246707f18b8bdb014643e7a    1
ebfbabd6e86ee48c24c3828f4ee1b92f6ff39f68    1
53b6ef015e8c8793036ec97b599fa436cd131b3f    1
2f9ed4c5926a0fcede392151f980e017c0c93acb    1
361d89bb4743deb2ef0a6d1cd847cd5a2c9cb7db    1
23796ef71f89aeadfa7a847ca66d62e557cfdbbb    1
346ecbfdd79cec2fad1ef9b4f5ed650b93705bf7    1
9561f88ffc8f31e9c7d0151d058ab8d7dc194fb3    1
5516cd8e1144e5e75d37e49c3a7ed54395946de6    1
Name: count, dtype: int64
26
