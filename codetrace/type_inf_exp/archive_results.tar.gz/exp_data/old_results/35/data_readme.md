Correct
fim_type
string          12
number          10
any              8
boolean          2
void             2
Schema           1
G                1
Vertex           1
Options          1
Point            1
U                1
Id               1
Section          1
K                1
Language         1
HttpResponse     1
Container        1
Instruction      1
offsets          1
Name: count, dtype: int64
hexsha
32fad88cf989fe13e31b63cb2ea82544e40b70b9    5
bf991cf13e41beda6a1e948184ea7f39b759886d    3
9eb078d7d68852e0860617c539c62b7d3a9f0a9a    2
3f56768763456223c2ba0b091b90831e3aa1b8b3    2
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    2
9232371dfa21a47ce397b18f5fd76f02d4b0d2b1    2
692b6650dfaec64762a5a63c3ed9a70a95671b5f    2
595681bb13aee410a4c20056b48f731d78418652    1
a3c87e22c30072055cfbcdaba851bef6a0244dc3    1
2cb59d73168b34abd1b1fdfe682092c10381edc8    1
d0d1086bff94aa89cca676745f39b6a620f49706    1
719d8ef7e693a43b35201b8bfe890e01809031ca    1
181ec44034d7ff44d9293788b657b1a2036d874b    1
4e77d6fefc465d02bbfde5576d003dda41ab6508    1
ccee70850d7be59ff29044ffd01e8ec90a3de543    1
eaa92966cbe116f28e1b5c9c0f4b724a32bab041    1
9d3356dc252d0a156c06c36e698d23701b6776da    1
5138dfd36b6faf2623d71cd5a35b381d02adc19f    1
bf712f9fe76a6eeeb69b15794f6333cb9c774f5e    1
54882c1b4f5afd785ff8918678f1ada0fdf4020a    1
e8163c19af6d0400d21846442a54c5e20ba9eac3    1
f5af1e91356527eb5d685f57986a63f3cc187b56    1
cc966119a9d0804aa81737f900326caade60f340    1
f77b40c49a005709dafda73e190c54efa502710e    1
db376862601a94fa1ae1b06de6200da26d207e77    1
5516cd8e1144e5e75d37e49c3a7ed54395946de6    1
4ab9eed9cbc53ed6e544dca10cf2f6417c2bdcd7    1
76a884ba965e8d7964d8852a0c0f228c1ae1d7ad    1
5bf8f0f2946da835300025c6804a609bef4277ab    1
97dca01248d8bc1f3e4e2fc93faa08dceabb61d6    1
1b0e94bf7d3c6477c0f89caf09f284b1c8441493    1
d7288789b6e870c947d9b5d2c8fe51bb8de33ca3    1
53b6ef015e8c8793036ec97b599fa436cd131b3f    1
346ecbfdd79cec2fad1ef9b4f5ed650b93705bf7    1
9561f88ffc8f31e9c7d0151d058ab8d7dc194fb3    1
bd5fedd15b33868f0983320e9179fbd4b6751d7e    1
fcdbbcb545071af17a684020e478305f1e8d06c9    1
Name: count, dtype: int64
48

Incorrect
fim_type
string          12
number          10
any              8
boolean          2
Schema           1
Container        1
HttpResponse     1
Language         1
Section          1
G                1
void             1
Id               1
U                1
Point            1
Options          1
offsets          1
Name: count, dtype: int64
hexsha
32fad88cf989fe13e31b63cb2ea82544e40b70b9    5
bf991cf13e41beda6a1e948184ea7f39b759886d    3
9eb078d7d68852e0860617c539c62b7d3a9f0a9a    2
3f56768763456223c2ba0b091b90831e3aa1b8b3    2
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    2
9232371dfa21a47ce397b18f5fd76f02d4b0d2b1    2
595681bb13aee410a4c20056b48f731d78418652    1
a3c87e22c30072055cfbcdaba851bef6a0244dc3    1
2cb59d73168b34abd1b1fdfe682092c10381edc8    1
d0d1086bff94aa89cca676745f39b6a620f49706    1
719d8ef7e693a43b35201b8bfe890e01809031ca    1
181ec44034d7ff44d9293788b657b1a2036d874b    1
4e77d6fefc465d02bbfde5576d003dda41ab6508    1
ccee70850d7be59ff29044ffd01e8ec90a3de543    1
9d3356dc252d0a156c06c36e698d23701b6776da    1
5138dfd36b6faf2623d71cd5a35b381d02adc19f    1
bf712f9fe76a6eeeb69b15794f6333cb9c774f5e    1
54882c1b4f5afd785ff8918678f1ada0fdf4020a    1
e8163c19af6d0400d21846442a54c5e20ba9eac3    1
f5af1e91356527eb5d685f57986a63f3cc187b56    1
cc966119a9d0804aa81737f900326caade60f340    1
db376862601a94fa1ae1b06de6200da26d207e77    1
692b6650dfaec64762a5a63c3ed9a70a95671b5f    1
5516cd8e1144e5e75d37e49c3a7ed54395946de6    1
4ab9eed9cbc53ed6e544dca10cf2f6417c2bdcd7    1
76a884ba965e8d7964d8852a0c0f228c1ae1d7ad    1
5bf8f0f2946da835300025c6804a609bef4277ab    1
97dca01248d8bc1f3e4e2fc93faa08dceabb61d6    1
1b0e94bf7d3c6477c0f89caf09f284b1c8441493    1
d7288789b6e870c947d9b5d2c8fe51bb8de33ca3    1
53b6ef015e8c8793036ec97b599fa436cd131b3f    1
346ecbfdd79cec2fad1ef9b4f5ed650b93705bf7    1
9561f88ffc8f31e9c7d0151d058ab8d7dc194fb3    1
fcdbbcb545071af17a684020e478305f1e8d06c9    1
Name: count, dtype: int64
44

Incorrect Eval
fim_type
boolean         2
RegExp          2
number          2
string          2
Actions         1
Key             1
any             1
SearchResult    1
Command         1
void            1
Name: count, dtype: int64
hexsha
2807516d2c064ba25b7c27dc711ae21133bfb5af    3
54795a90e2bd17f0016b0a39e21d9821b144d333    2
ebfbabd6e86ee48c24c3828f4ee1b92f6ff39f68    1
23796ef71f89aeadfa7a847ca66d62e557cfdbbb    1
361d89bb4743deb2ef0a6d1cd847cd5a2c9cb7db    1
2f9ed4c5926a0fcede392151f980e017c0c93acb    1
ac2f2620a73cd8792597b3c5d3baa98411d6543c    1
d7180447147db133f246707f18b8bdb014643e7a    1
d7888589a5edea554ef38b5038cfe5db0eca64de    1
e5e071d82c234e126b482cc77c6bdea7b5f5be72    1
4ecebdfe2a83e32ca2665144d05b64c53181178a    1
Name: count, dtype: int64
14
