## Steering Results
24 / 63 = 0.38095238095238093
## Arguments
outdir : 38
dataset : franlucc/stenotype-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 100
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13]
test_size : 0.1

Eval type distribution
Counter({'string': 21, 'RegExp': 8, 'Function': 7, 'number': 7, 'Color': 7, 'T': 3, 'void': 3, 'Point': 3, 'object': 2, 'I': 1, 'TypeDef': 1})