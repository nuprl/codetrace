## Steering Results
success
False    12## Arguments
outdir_idx : 1
dataset : franlucc/starcoderbase-1b-completions_typeinf_analysis
model : /home/arjun/models/starcoderbase-1b
correct_prog_threshold : 4
correct_type_threshold : 6
incorrect_prog_threshold : 4
incorrect_type_threshold : 6
batch_size : 2
patch_mode : add
n_eval : 15
tokens_to_patch : ['<fim_prefix>', '<fim_suffix>', '<fim_middle>']
layers_to_patch : [14]
module_to_patch : block_out
