Correct
fim_type
string    7
number    6
RegExp    3
Point     3
void      3
T         3
I         1
Name: count, dtype: int64
hexsha
35b6c6d6cf43374159e7f7c86517b7faf952db91    3
bd5fedd15b33868f0983320e9179fbd4b6751d7e    3
ac2f2620a73cd8792597b3c5d3baa98411d6543c    3
d7180447147db133f246707f18b8bdb014643e7a    3
719d8ef7e693a43b35201b8bfe890e01809031ca    3
4ecebdfe2a83e32ca2665144d05b64c53181178a    3
9b43716649831a6b0a5fff85e210dfc54b96687f    3
bf991cf13e41beda6a1e948184ea7f39b759886d    3
32fad88cf989fe13e31b63cb2ea82544e40b70b9    1
e0adc0a947e9e83b8bc03219033fde3d085cbfad    1
Name: count, dtype: int64
26

Incorrect
fim_type
string    7
number    6
RegExp    3
Point     3
void      3
T         3
I         1
Name: count, dtype: int64
hexsha
35b6c6d6cf43374159e7f7c86517b7faf952db91    3
bd5fedd15b33868f0983320e9179fbd4b6751d7e    3
ac2f2620a73cd8792597b3c5d3baa98411d6543c    3
d7180447147db133f246707f18b8bdb014643e7a    3
719d8ef7e693a43b35201b8bfe890e01809031ca    3
4ecebdfe2a83e32ca2665144d05b64c53181178a    3
9b43716649831a6b0a5fff85e210dfc54b96687f    3
bf991cf13e41beda6a1e948184ea7f39b759886d    3
32fad88cf989fe13e31b63cb2ea82544e40b70b9    1
e0adc0a947e9e83b8bc03219033fde3d085cbfad    1
Name: count, dtype: int64
26

Incorrect Eval
fim_type
Function    3
Color       3
TypeDef     1
Name: count, dtype: int64
hexsha
4dc1c64fd20c06b5dceaa99125c0a14b4492067c    3
46db563dd7e7f7a5daf1c6d96ede4b374aba6ef3    3
8dd4eba467cc4f8c283713bdfc23d3b71e87f31d    1
Name: count, dtype: int64
7
