## Steering Results
10 / 26 = 0.38461538461538464
## Arguments
outdir : 39
dataset : franlucc/stenotype-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 3
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.1

Eval type distribution
Counter({'string': 7, 'number': 6, 'RegExp': 3, 'Point': 3, 'void': 3, 'T': 3, 'I': 1})