## Steering Results
31 / 73 = 0.4246575342465753
## Arguments
outdir : 41
dataset : franlucc/ts-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 30
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_suffix>', '<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 25, 'number': 16, 'boolean': 8, 'any': 6, 'Type': 2, 'unknown': 2, 'Date': 2, 'Options': 1, 'TResult': 1, 'Instruction': 1, 'ServiceProvider': 1, 'Rule': 1, 'void': 1, 'None': 1, 'Element': 1, 'Area': 1, 'Address': 1, 'T': 1, 'Bounds': 1})