## Steering Results
5 / 13 = 0.38461538461538464
## Arguments
outdir : 45
dataset : franlucc/stenotype-typeinf-steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'number': 15, 'string': 8, 'any': 7, 'boolean': 4, 'void': 3, 'unknown': 2, 'Workflow': 1, 'Color': 1, 'Heap': 1, 'Organization': 1, 'T': 1, 'Id': 1, 'Command': 1, 'Point': 1, 'JsonValue': 1, 'RegExp': 1, 'Order': 1, 'HttpResponse': 1, 'SearchResult': 1, 'Position': 1})