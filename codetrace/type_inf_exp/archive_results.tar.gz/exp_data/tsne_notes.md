# NOTE

steered prompt TSNE projections are more clustered around type clusters than non-steering. Successful steering examples are in middle of clusters of similar types. This seems robust to different perplexity values.

What does this mean?

- steering works robustly (?) in some cases, but not all -- not outliers
- maybe good case for training module steer?