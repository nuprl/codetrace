## Steering Results
96 / 224 = 0.42857142857142855
## Arguments
outdir : 51
dataset : franlucc/ts-typeinf-steering-p0
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 1
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'string': 82, 'number': 51, 'any': 31, 'boolean': 18, 'void': 8, 'Date': 3, 'T': 2, 'unknown': 2, 'Params': 1, 'JSONObject': 1, 'Orientation': 1, 'never': 1, 'DateRange': 1, 'Capabilities': 1, 'Paths': 1, 'Input': 1, 'float': 1, 'P': 1, 'Matrix': 1, 'ByteArray': 1, 'Length': 1, 'Pos': 1, 'B': 1, 'K': 1, 'FS': 1, 'Address': 1, 'Point': 1, 'Node': 1, 'Vec': 1, 'Weights': 1, 'BigInt': 1, 'M': 1, 'Calculator': 1, 'Request': 1, 'ListNode': 1})