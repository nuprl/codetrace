## Optimal steering config

Run v25

Important for steering: 
- having lots of different seed programs (variety for avg vector). In the 100s
- Not too many duplicate programs.
- OOD performance depends on whether that type is in fitting dataset?