## Steering Results
2 / 41 = 0.04878048780487805
## Arguments
outdir : 50
dataset : franlucc/ts-typeinf-1tok-completions
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 2
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'any': 63, 'string': 28, 'number': 25, 'unknown': 9, 'Object': 5, 'object': 4, 'void': 3, 'Boolean': 3, 'T': 3, 'Error': 3, 'K': 2, 'Element': 1, 'Tuple': 1, 'ValueType': 1, 'ListNode': 1, 'Vector': 1, 'Number': 1, 'String': 1, 'Digit': 1, 'Timestamp': 1, 'Color': 1, 'Ticker': 1, 'boolean': 1, '[]': 1, 'Function': 1, 'JSON': 1, 'jo': 1})