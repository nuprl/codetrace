## Steering Results
0 / 3 = 0.0
## Arguments
outdir : 53
dataset : franlucc/fim_items_10k_steering
model : /home/arjun/models/starcoderbase-1b
prog_threshold : 1
type_threshold : 100
batch_size : 1
patch_mode : add
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0.2

Eval type distribution
Counter({'str': 5, 'int': 2, 'datetime': 2, 'float': 1, 'Event': 1, 'Recipient': 1, 'Stock': 1, 'PID': 1})