## Steering Results
success
False    20
True      5
## Arguments
outdir_idx : 6
dataset : franlucc/starcoderbase-1b-completions_typeinf_analysis
model : /home/arjun/models/starcoderbase-1b
correct_prog_threshold : 1
correct_type_threshold : 1
incorrect_prog_threshold : 1
incorrect_type_threshold : 1
batch_size : 2
patch_mode : add
n_eval : 25
tokens_to_patch : ['<fim_middle>']
layers_to_patch : [14, 15, 16, 17, 18]
module_to_patch : block_out
