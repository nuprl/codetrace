## Steering Results
0 / 5 = 0.0
## Arguments
outdir : 32
dataset : franlucc/stenotype-type-inference-renamed-eval-v1
model : /home/arjun/models/starcoderbase-1b
correct_prog_threshold : 1000
correct_type_threshold : 1000
incorrect_prog_threshold : 1000
incorrect_type_threshold : 1000
batch_size : 2
patch_mode : add
n_eval : 5
tokens_to_patch : ['<fim_suffix>', '<fim_middle>']
layers_to_patch : [10, 11, 12, 13, 14]
test_size : 0

Eval type distribution
Counter({'number': 3, 'Order': 1, 'string': 1})