Correct
fim_type
number         3
Order          1
string         1
Instruction    1
Name: count, dtype: int64
hexsha
35b6c6d6cf43374159e7f7c86517b7faf952db91    2
bd5fedd15b33868f0983320e9179fbd4b6751d7e    2
33b7ca5e8483474f1e5fef02a305e0919a37eae4    1
3f56768763456223c2ba0b091b90831e3aa1b8b3    1
Name: count, dtype: int64
6

Incorrect
fim_type
number    3
Order     1
string    1
Name: count, dtype: int64
hexsha
35b6c6d6cf43374159e7f7c86517b7faf952db91    2
33b7ca5e8483474f1e5fef02a305e0919a37eae4    1
3f56768763456223c2ba0b091b90831e3aa1b8b3    1
bd5fedd15b33868f0983320e9179fbd4b6751d7e    1
Name: count, dtype: int64
5

Incorrect Eval
fim_type
number    3
Order     1
string    1
Name: count, dtype: int64
hexsha
35b6c6d6cf43374159e7f7c86517b7faf952db91    2
33b7ca5e8483474f1e5fef02a305e0919a37eae4    1
3f56768763456223c2ba0b091b90831e3aa1b8b3    1
bd5fedd15b33868f0983320e9179fbd4b6751d7e    1
Name: count, dtype: int64
5
